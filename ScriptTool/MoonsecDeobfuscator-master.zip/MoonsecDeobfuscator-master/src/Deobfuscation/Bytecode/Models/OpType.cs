﻿namespace MoonsecDeobfuscator.Bytecode.Models;

public enum OpType
{
    AB,
    ABx,
    ABC,
    sBx,
    AC,
    AsBx,
    A,
    None
}