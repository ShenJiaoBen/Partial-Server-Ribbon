﻿namespace MoonsecDeobfuscator.Ast;

public enum Order
{
    PreOrder,
    PostOrder
}