﻿namespace MoonsecDeobfuscator.Ast.Expressions;

public abstract class Variable : Expression
{
    public abstract override Variable Clone();
}